# MedievalCannons 2.0

Plugin experimental para servidores Minecraft Java Paper/Purpur, escrito para Java 25.

## Recursos
- Interface de inventário (`/canhao`) com botões de carregar pólvora, carregar TNT, ajustar elevação, girar mira, disparar e modo de mira.
- Canhão registrado por barril; mire para um barril e use `/canhao criar`.
- Projétil visível, trajetória aproximada com partículas, impacto explosivo configurável.
- Configuração de potência, velocidade, cooldown, munição e dano a blocos.
- Comandos administrativos para criar/remover canhões.

## Importante sobre a versão
A versão de API do Paper `26.2` pode variar por build e disponibilidade no repositório. O `build.gradle.kts` usa uma propriedade `paperApiVersion` configurável (padrão `26.2.build.+`). Se o repositório não resolver esse artefato, defina a versão exata de API publicada para seu servidor no `gradle.properties` ou `build.gradle.kts`.
Este projeto não foi executado em um servidor Minecraft real. O teste de compilação deve ser feito pelo GitHub Actions ou em ambiente com Gradle e a API correspondente.

## Build local
Requer JDK 25 e Gradle 8.14+:
```bash
gradle build
```
JAR: `build/libs/MedievalCannons-2.0.0.jar`

## Instalação
1. Copie o JAR para `plugins/` do Paper/Purpur.
2. Reinicie o servidor.
3. Mire para um barril e use `/canhao criar`.
4. Mire no barril e use `/canhao` para abrir a interface.
5. Clique nos botões da interface para carregar e disparar.

## Comandos
- `/canhao` — abre a interface do canhão registrado mais próximo ou o que você está mirando.
- `/canhao criar` — registra o barril mirado (permissão `medievalcannons.admin`).
- `/canhao remover` — remove o barril mirado.
- `/canhao ajuda` — mostra ajuda.

## Segurança
Explosões podem destruir blocos e causar lag. Teste num mundo de teste e ajuste `explosion-power` e `damage-blocks` em `config.yml`.


## Central de Defesa Mágica

- Receita: diamantes nos dois cantos superiores, beacon no centro e barras de netherita nos dois cantos inferiores.
- Coloque o item fabricado para ativar a central. Ela bloqueia explosões numa esfera de raio configurável (padrão: 75 blocos).
- A barreira absorve até 8 explosões por padrão. Ao esgotar a carga, a barreira se dissipa, mas o beacon continua colocado.
- Clique com o botão direito no beacon para abrir o painel. O botão de visão liga/desliga as partículas sem desligar a proteção. Também é possível mirar no beacon e usar `/canhao defesa`.
- Os valores ficam em `defense.radius-blocks` e `defense.max-explosions` no `config.yml`.

**Nota:** este projeto foi atualizado no código-fonte, mas ainda precisa ser compilado e testado no servidor Paper/Purpur alvo.


## Central de Defesa Mágica (atualização)

- Receita: diamantes nos cantos superiores, beacon normal no centro e barras de netherita nos cantos inferiores. O quadrado roxo visto em uma ilustração anterior era apenas um símbolo visual, não um ingrediente; use barras de netherita.
- Proteção em volume elipsoidal: 60 blocos para cada lado horizontal e 80 blocos acima/abaixo do beacon.
- Até 8 explosões bloqueadas por carga. Ao esgotar, o escudo se dissipa e o beacon permanece.
- Recarga automática gradual: cada carga retorna em aproximadamente 3 minutos e 7,5 segundos, totalizando 25 minutos para recuperar 8 cargas. Não é necessário inserir itens.
- Clique com o botão direito na central para abrir uma interface própria de 45 slots. O botão de projeção alterna as partículas visuais sem desligar a proteção. O painel informa as cargas e o tempo estimado para a próxima.
- Também é possível mirar na central e usar `/canhao defesa`.

Observação: o código-fonte foi atualizado, mas precisa ser compilado e testado no ambiente Paper/Purpur alvo antes de ser instalado no servidor.


## MedievalCannons 2.1 — integração e receitas

- Canhão: ao colocar o barril fabricado, o plugin registra o canhão automaticamente.
- Receita do canhão (linha a linha): `IFI` / `BTB` / `PRP`; I=lingote de ferro, F=pederneira e aço, B=bloco de ferro, T=barril, P=pólvora, R=redstone.
- O canhão consome apenas TNT de Impulso marcada pelo plugin TNTReinforced 1.3.0 (`tntreinforced:tnt_impulse_item`), não TNT comum nem pólvora. Mantenha TNTReinforced instalado para obter e identificar essa munição.
- Alcance máximo do projétil: 65 blocos; potência, recarga e dano ao terreno permanecem configuráveis.
- Barreira mágica normal: `D D` / ` B ` / `N N`; D=diamante, B=beacon, N=lingote de netherita; até 8 cargas.
- Barreira mágica reforçada: `ANA` / `NBN` / `ANA`; A=fragmento de ametista, N=lingote de netherita, B=beacon; até 12 cargas.

## Créditos
- MedievalCannons base e integração: ElementalCraft BR.
- Compatibilidade da TNT de Impulso: integração baseada nos identificadores públicos do item do TNTReinforced 1.3.0, de zSouul. TNTReinforced permanece um plugin separado e deve estar instalado para criar/obter a munição especial.

## Compilação
Requer JDK 25 e Gradle 8.14+ conforme `build.gradle.kts`. Execute `gradle build`; o JAR será criado em `build/libs/MedievalCannons-2.1.0.jar`. Teste primeiro em servidor de teste.
