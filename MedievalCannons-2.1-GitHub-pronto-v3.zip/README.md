# MedievalCannons 2.0

Plugin experimental para servidores Minecraft Java Paper/Purpur, escrito para Java 25.

## Recursos
- Interface de inventário (`/canhao`) com botões de carregar pólvora, carregar TNT, ajustar elevação, girar mira, disparar e modo de mira.
- Canhão registrado por barril; mire para um barril e use `/canhao criar`.
- Projétil visível, trajetória aproximada com partículas, impacto explosivo configurável.
- Configuração de potência, velocidade, cooldown, munição e dano a blocos.
- Comandos administrativos para criar/remover canhões.

## Importante sobre a versão
A versão de API do Paper `26.2` pode variar por build e disponibilidade no repositório. O `build.gradle.kts` usa uma propriedade `paperApiVersion` configurável (padrão `26.2.build.+`). Se o repositório não resolver esse artefato, defina a versão exata de API publicada para seu servidor no `gradle.properties` ou `build.gradle.kts`.
Este projeto não foi executado em um servidor Minecraft real. O teste de compilação deve ser feito pelo GitHub Actions ou em ambiente com Gradle e a API correspondente.

## Build local
Requer JDK 25 e Gradle 8.14+:
```bash
gradle build
```
JAR: `build/libs/MedievalCannons-2.0.0.jar`

## Instalação
1. Copie o JAR para `plugins/` do Paper/Purpur.
2. Reinicie o servidor.
3. Mire para um barril e use `/canhao criar`.
4. Mire no barril e use `/canhao` para abrir a interface.
5. Clique nos botões da interface para carregar e disparar.

## Comandos
- `/canhao` — abre a interface do canhão registrado mais próximo ou o que você está mirando.
- `/canhao criar` — registra o barril mirado (permissão `medievalcannons.admin`).
- `/canhao remover` — remove o barril mirado.
- `/canhao ajuda` — mostra ajuda.

## Segurança
Explosões podem destruir blocos e causar lag. Teste num mundo de teste e ajuste `explosion-power` e `damage-blocks` em `config.yml`.


## Central de Defesa Mágica

- Receita: esmeraldas nos dois cantos superiores, beacon no centro e blocos de ouro nos dois cantos inferiores.
- Coloque o item fabricado para ativar a central. Ela bloqueia explosões numa esfera de raio configurável (padrão: 75 blocos).
- A barreira absorve até 8 explosões por padrão. Ao esgotar a carga, a barreira se dissipa, mas o beacon continua colocado.
- Clique com o botão direito no beacon para abrir o painel. O botão de visão liga/desliga as partículas sem desligar a proteção. Também é possível mirar no beacon e usar `/canhao defesa`.
- Os valores ficam em `defense.radius-blocks` e `defense.max-explosions` no `config.yml`.

**Nota:** este projeto foi atualizado no código-fonte, mas ainda precisa ser compilado e testado no servidor Paper/Purpur alvo.


## Central de Defesa Mágica (atualização)

- Receita: esmeraldas nos dois cantos superiores, beacon normal no centro e blocos de ouro nos dois cantos inferiores. O quadrado roxo visto em uma ilustração anterior era apenas um símbolo visual, não um ingrediente; use barras de netherita.
- Proteção em volume elipsoidal: 50 blocos para os lados e 50 blocos verticalmente.
- Até 8 explosões bloqueadas por carga. Ao esgotar, o escudo se dissipa e o beacon permanece.
- Recarga automática gradual: total de 10 minutos para recuperar 8 cargas. Não é necessário inserir itens.
- Clique com o botão direito na central para abrir uma interface própria de 45 slots. O botão de projeção alterna as partículas visuais sem desligar a proteção. O painel informa as cargas e o tempo estimado para a próxima.
- Também é possível mirar na central e usar `/canhao defesa`.

Observação: o código-fonte foi atualizado, mas precisa ser compilado e testado no ambiente Paper/Purpur alvo antes de ser instalado no servidor.


## MedievalCannons 2.1 — integração e receitas

- Canhão: ao colocar o barril fabricado, o plugin registra o canhão automaticamente.
- Receita do canhão (linha a linha): `IFI` / `BTB` / `PRP`; I=lingote de ferro, F=pederneira e aço, B=bloco de ferro, T=barril, P=pólvora, R=redstone.
- O canhão consome apenas TNT de Impulso marcada pelo plugin TNTReinforced 1.3.0 (`tntreinforced:tnt_impulse_item`), não TNT comum nem pólvora. Mantenha TNTReinforced instalado para obter e identificar essa munição.
- Alcance máximo do projétil: 65 blocos; recarga do canhão: 5 segundos; potência, recarga e dano ao terreno permanecem configuráveis.
- Barreira mágica normal: `E E` / ` B ` / `G G`; E=esmeralda, B=beacon, G=bloco de ouro; até 8 cargas.
- Barreira mágica reforçada: `ONO` / `NBN` / `ONO`; O=obsidiana chorona, N=lingote de netherita, B=beacon. Receita avançada: 4 lingotes de netherita, 4 obsidianas choronas e 1 beacon. Proteção: 80 blocos na horizontal, 100 na vertical, 16 cargas e recarga completa em 45 minutos.

## Créditos
- MedievalCannons base e integração: ElementalCraft BR.
- Compatibilidade da TNT de Impulso: integração baseada nos identificadores públicos do item do TNTReinforced 1.3.0, de zSouul. TNTReinforced permanece um plugin separado e deve estar instalado para criar/obter a munição especial.

## Compilação
Requer JDK 25 e Gradle 8.14+ conforme `build.gradle.kts`. Execute `gradle build`; o JAR será criado em `build/libs/MedievalCannons-2.1.0.jar`. Teste primeiro em servidor de teste.


## Ajustes solicitados para a versão 2.1
- Canhão: alcance máximo 65 blocos e cooldown de 5 segundos.
- Defesa normal: raio horizontal/vertical de 50 blocos, 8 cargas e recarga total de 10 minutos.
- Barreira reforçada: receita difícil com 4 lingotes de netherita, 4 obsidianas choronas e 1 beacon; alcance horizontal 80, vertical 100, até 16 cargas e recarga total de 45 minutos.
- O workflow publica o JAR como artefato do GitHub Actions. Ainda é obrigatório confirmar build verde e testar em servidor.
