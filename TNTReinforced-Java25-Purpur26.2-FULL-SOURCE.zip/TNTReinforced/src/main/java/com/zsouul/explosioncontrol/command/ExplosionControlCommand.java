package com.zsouul.explosioncontrol.command;

import com.zsouul.explosioncontrol.config.ConfigManager;
import com.zsouul.explosioncontrol.impulse.TntImpulseManager;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.logging.Level;
import java.util.stream.Collectors;

/** Admin commands for TNTReinforced. */
public final class ExplosionControlCommand implements CommandExecutor, TabCompleter {
    private static final List<String> SUBCOMMANDS = List.of("reload", "giveimpulse");
    private final JavaPlugin plugin;
    private final ConfigManager configManager;
    private final TntImpulseManager tntImpulseManager;

    public ExplosionControlCommand(JavaPlugin plugin, ConfigManager configManager, TntImpulseManager tntImpulseManager) {
        this.plugin = plugin;
        this.configManager = configManager;
        this.tntImpulseManager = tntImpulseManager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 1 && args[0].equalsIgnoreCase("reload")) {
            if (!sender.hasPermission("tntreinforced.admin") && !sender.hasPermission("explosioncontrol.reload")) {
                sender.sendMessage(Component.text("Você não tem permissão para isso.", NamedTextColor.RED));
                return true;
            }
            return handleReload(sender);
        }
        if ((args.length == 1 || args.length == 2) && args[0].equalsIgnoreCase("giveimpulse")) {
            if (!sender.hasPermission("tntreinforced.admin")) {
                sender.sendMessage(Component.text("Você não tem permissão para isso.", NamedTextColor.RED));
                return true;
            }
            return handleGiveImpulse(sender, args.length == 2 ? args[1] : null);
        }
        sender.sendMessage(Component.text("Uso: /tntreinforced reload", NamedTextColor.YELLOW));
        sender.sendMessage(Component.text("Uso: /tntreinforced giveimpulse [jogador]", NamedTextColor.YELLOW));
        return true;
    }

    private boolean handleReload(CommandSender sender) {
        try {
            configManager.load();
            int categoryCount = configManager.getAllSettings().size();
            sender.sendMessage(Component.text()
                    .append(Component.text("TNTReinforced: ", NamedTextColor.GOLD))
                    .append(Component.text("config.yml recarregado (", NamedTextColor.GREEN))
                    .append(Component.text(String.valueOf(categoryCount), NamedTextColor.YELLOW))
                    .append(Component.text(" categorias de explosão).", NamedTextColor.GREEN))
                    .build());
        } catch (Exception ex) {
            sender.sendMessage(Component.text("Falha ao recarregar config.yml. Confira o console.", NamedTextColor.RED));
            plugin.getLogger().log(Level.SEVERE, "Failed to reload TNTReinforced configuration", ex);
        }
        return true;
    }

    private boolean handleGiveImpulse(CommandSender sender, String targetName) {
        Player target;
        if (targetName == null) {
            if (!(sender instanceof Player player)) {
                sender.sendMessage(Component.text("Informe um jogador: /tntreinforced giveimpulse <jogador>", NamedTextColor.RED));
                return true;
            }
            target = player;
        } else {
            target = Bukkit.getPlayerExact(targetName);
            if (target == null) {
                sender.sendMessage(Component.text("Jogador não encontrado ou não está online.", NamedTextColor.RED));
                return true;
            }
        }
        target.getInventory().addItem(tntImpulseManager.createItem()).values()
                .forEach(item -> target.getWorld().dropItemNaturally(target.getLocation(), item));
        sender.sendMessage(Component.text("TNT de Impulso entregue para " + target.getName() + ".", NamedTextColor.GREEN));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (!sender.hasPermission("tntreinforced.admin") && !sender.hasPermission("explosioncontrol.reload")) {
            return List.of();
        }
        if (args.length == 1) {
            String partial = args[0].toLowerCase(Locale.ROOT);
            List<String> allowed = sender.hasPermission("tntreinforced.admin")
                    ? SUBCOMMANDS : List.of("reload");
            return allowed.stream().filter(sub -> sub.startsWith(partial)).collect(Collectors.toList());
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("giveimpulse")
                && sender.hasPermission("tntreinforced.admin")) {
            String partial = args[1].toLowerCase(Locale.ROOT);
            List<String> names = new ArrayList<>();
            for (Player player : Bukkit.getOnlinePlayers()) {
                if (player.getName().toLowerCase(Locale.ROOT).startsWith(partial)) {
                    names.add(player.getName());
                }
            }
            return names;
        }
        return List.of();
    }
}
