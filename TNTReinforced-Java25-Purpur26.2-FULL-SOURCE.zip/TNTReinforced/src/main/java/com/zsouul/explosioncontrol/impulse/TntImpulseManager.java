package com.zsouul.explosioncontrol.impulse;

import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.block.Block;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.TNTPrimed;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.Vector;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;

import java.util.ArrayList;
import java.util.List;

/** Handles the custom, terrain-safe TNT Impulse item and its recipe. */
public final class TntImpulseManager implements Listener {
    private static final int DEFAULT_FUSE_TICKS = 60;
    private static final double LAUNCH_RADIUS = 6.0D;
    private final JavaPlugin plugin;
    private final NamespacedKey itemKey;
    private final NamespacedKey entityKey;
    private final NamespacedKey recipeKey;
    private final NamespacedKey normalTntRecipeKey;

    public TntImpulseManager(JavaPlugin plugin) {
        this.plugin = plugin;
        this.itemKey = new NamespacedKey(plugin, "tnt_impulse_item");
        this.entityKey = new NamespacedKey(plugin, "tnt_impulse_entity");
        this.recipeKey = new NamespacedKey(plugin, "tnt_impulse_recipe");
        this.normalTntRecipeKey = new NamespacedKey(plugin, "reinforced_tnt_recipe");
    }

    public void registerRecipe() {
        ShapedRecipe impulseRecipe = new ShapedRecipe(recipeKey, createItem());
        impulseRecipe.shape("TT", "TT");
        impulseRecipe.setIngredient('T', Material.TNT);
        plugin.getServer().addRecipe(impulseRecipe);

        // Additional easy recipe requested for the server; the vanilla recipe remains available.
        ShapedRecipe normalTntRecipe = new ShapedRecipe(normalTntRecipeKey, new ItemStack(Material.TNT, 1));
        normalTntRecipe.shape("SG", "GS");
        normalTntRecipe.setIngredient('S', Material.SAND);
        normalTntRecipe.setIngredient('G', Material.GUNPOWDER);
        plugin.getServer().addRecipe(normalTntRecipe);
    }

    public void unregisterRecipes() {
        plugin.getServer().removeRecipe(recipeKey);
        plugin.getServer().removeRecipe(normalTntRecipeKey);
    }

    public ItemStack createItem() {
        ItemStack item = new ItemStack(Material.TNT, 2);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text("TNT de Impulso", NamedTextColor.AQUA));
        meta.lore(List.of(
                Component.text("Não destrói blocos", NamedTextColor.GREEN),
                Component.text("Lança TNTs ativadas próximas", NamedTextColor.GRAY),
                Component.text("Use com o botão direito em um bloco", NamedTextColor.DARK_GRAY)
        ));
        meta.getPersistentDataContainer().set(itemKey, PersistentDataType.BYTE, (byte) 1);
        item.setItemMeta(meta);
        return item;
    }

    public boolean isImpulseEntity(Entity entity) {
        return entity instanceof TNTPrimed tnt
                && tnt.getPersistentDataContainer().has(entityKey, PersistentDataType.BYTE);
    }

    /** Called before the normal resistance handler so impulse blasts never consume wall hits. */
    public void handleImpulseExplosion(org.bukkit.event.entity.EntityExplodeEvent event) {
        if (!isImpulseEntity(event.getEntity())) {
            return;
        }
        event.blockList().clear();
        Entity source = event.getEntity();
        Vector center = source.getLocation().toVector();
        List<TNTPrimed> nearby = new ArrayList<>();
        for (Entity entity : source.getWorld().getNearbyEntities(source.getLocation(), LAUNCH_RADIUS, LAUNCH_RADIUS, LAUNCH_RADIUS)) {
            if (entity instanceof TNTPrimed tnt && !tnt.getUniqueId().equals(source.getUniqueId())) {
                nearby.add(tnt);
            }
        }
        for (TNTPrimed tnt : nearby) {
            Vector direction = tnt.getLocation().toVector().subtract(center);
            if (direction.lengthSquared() < 0.01D) {
                direction = new Vector(0.0D, 0.5D, 0.0D);
            } else {
                direction.normalize().multiply(1.6D);
                direction.setY(Math.max(0.45D, direction.getY() + 0.65D));
            }
            tnt.setVelocity(direction);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onUse(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) {
            return;
        }
        Action action = event.getAction();
        if (action != Action.RIGHT_CLICK_BLOCK || event.getClickedBlock() == null) {
            return;
        }
        ItemStack held = event.getItem();
        if (held == null || held.getType() != Material.TNT || !isImpulseItem(held)) {
            return;
        }

        Player player = event.getPlayer();
        Block target = event.getClickedBlock().getRelative(event.getBlockFace());
        if (!target.getType().isAir() && !target.isPassable()) {
            player.sendMessage(Component.text("Não há espaço para colocar a TNT de Impulso.", NamedTextColor.RED));
            event.setCancelled(true);
            return;
        }

        event.setCancelled(true);
        ItemStack remaining = held.clone();
        remaining.setAmount(held.getAmount() - 1);
        player.getInventory().setItemInMainHand(remaining.getAmount() <= 0 ? null : remaining);

        org.bukkit.Location spawn = target.getLocation().add(0.5D, 0.15D, 0.5D);
        TNTPrimed tnt = target.getWorld().spawn(spawn, TNTPrimed.class);
        tnt.setFuseTicks(DEFAULT_FUSE_TICKS);
        tnt.setSource(player);
        tnt.getPersistentDataContainer().set(entityKey, PersistentDataType.BYTE, (byte) 1);
    }

    private boolean isImpulseItem(ItemStack item) {
        if (!item.hasItemMeta()) {
            return false;
        }
        return item.getItemMeta().getPersistentDataContainer().has(itemKey, PersistentDataType.BYTE);
    }
}
