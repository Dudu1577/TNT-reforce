package com.zsouul.explosioncontrol.listener;

import com.zsouul.explosioncontrol.cache.ExplosionOriginRegistry;
import com.zsouul.explosioncontrol.config.ConfigManager;
import com.zsouul.explosioncontrol.config.ExplosionSettings;
import com.zsouul.explosioncontrol.model.ExplosionCategory;
import com.zsouul.explosioncontrol.resolver.ExplosionSourceResolver;
import com.zsouul.explosioncontrol.resistance.BlockResistanceManager;
import com.zsouul.explosioncontrol.impulse.TntImpulseManager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityExplodeEvent;

/**
 * Applies {@code block-damage} to entity-sourced explosions by clearing the affected block
 * list, and re-checks {@code enabled} as a defensive fallback (the primary enforcement point
 * is {@link ExplosionPrimeListener}, which runs earlier and also prevents entity damage).
 * <p>
 * Clearing {@link EntityExplodeEvent#blockList()} rather than cancelling the whole event is
 * deliberate: it preserves entity damage/knockback (already resolved separately) while simply
 * leaving the terrain untouched, which is exactly what {@code block-damage: false} promises.
 * <p>
 * Also records into {@link ExplosionOriginRegistry} as a defensive backup, in case
 * {@link ExplosionPrimeListener} didn't get a chance to (e.g. a future explosion source this
 * plugin doesn't yet special-case).
 */
public final class EntityExplodeListener implements Listener {

    private final ConfigManager configManager;
    private final ExplosionOriginRegistry originRegistry;
    private final BlockResistanceManager blockResistanceManager;
    private final TntImpulseManager tntImpulseManager;

    public EntityExplodeListener(ConfigManager configManager, ExplosionOriginRegistry originRegistry, BlockResistanceManager blockResistanceManager, TntImpulseManager tntImpulseManager) {
        this.configManager = configManager;
        this.originRegistry = originRegistry;
        this.blockResistanceManager = blockResistanceManager;
        this.tntImpulseManager = tntImpulseManager;
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onEntityExplode(EntityExplodeEvent event) {
        if (tntImpulseManager.isImpulseEntity(event.getEntity())) {
            tntImpulseManager.handleImpulseExplosion(event);
            return;
        }
        ExplosionCategory category = ExplosionSourceResolver.resolve(event.getEntity());
        ExplosionSettings settings = configManager.getSettings(category);

        if (!settings.enabled()) {
            event.setCancelled(true);
            return;
        }

        originRegistry.record(event.getLocation(), category);

        if (!settings.blockDamage() && !event.blockList().isEmpty()) {
            event.blockList().clear();
            return;
        }
        blockResistanceManager.protectBlocks(event.blockList());
        if (settings.blockDamage()) {
            blockResistanceManager.protectSpecialObsidian(event.getLocation(),
                    Math.max(0.0D, configManager.getSpecialBlockScanRadius()), event.blockList(), event.getYield());
        }
    }
}
