package com.zsouul.explosioncontrol.resistance;

import org.bukkit.FluidCollisionMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ThreadLocalRandom;

/** Stores cumulative explosion impacts for configured blocks. */
public final class BlockResistanceManager {
    private final JavaPlugin plugin;
    private final File file;
    private YamlConfiguration hits;

    public BlockResistanceManager(JavaPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "block-hits.yml");
        load();
    }

    private void load() {
        if (!plugin.getDataFolder().exists() && !plugin.getDataFolder().mkdirs()) {
            plugin.getLogger().warning("Could not create plugin data directory; block hit progress may not persist.");
        }
        hits = YamlConfiguration.loadConfiguration(file);
    }

    /**
     * Removes configured blocks from the vanilla affected-block list until their Nth impact.
     * A durability of N means N-1 blocked impacts and destruction on impact N.
     */
    public void protectBlocks(List<Block> affectedBlocks) {
        boolean changed = false;
        Iterator<Block> iterator = affectedBlocks.iterator();
        while (iterator.hasNext()) {
            Block block = iterator.next();
            int durability = getDurability(block.getType());
            if (durability <= 1) {
                continue;
            }
            boolean destroyedThisHit = registerImpact(block, durability);
            changed = true;
            if (!destroyedThisHit) {
                iterator.remove();
            }
        }
        if (changed) {
            save();
        }
    }

    /**
     * Vanilla explosions usually omit obsidian from the affected-block list entirely.
     * This bounded ray-trace approximation gives configured obsidian cumulative resistance
     * without counting blocks hidden behind another solid block.
     */
    public void protectSpecialObsidian(Location origin, double radius, List<Block> alreadyAffected, float yield) {
        if (origin.getWorld() == null || radius <= 0.0D) {
            return;
        }
        int durability = getDurability(Material.OBSIDIAN);
        if (durability <= 1) {
            return;
        }
        World world = origin.getWorld();
        int minX = (int) Math.floor(origin.getX() - radius);
        int maxX = (int) Math.ceil(origin.getX() + radius);
        int minY = Math.max(world.getMinHeight(), (int) Math.floor(origin.getY() - radius));
        int maxY = Math.min(world.getMaxHeight() - 1, (int) Math.ceil(origin.getY() + radius));
        int minZ = (int) Math.floor(origin.getZ() - radius);
        int maxZ = (int) Math.ceil(origin.getZ() + radius);
        boolean changed = false;

        for (int x = minX; x <= maxX; x++) {
            for (int y = minY; y <= maxY; y++) {
                for (int z = minZ; z <= maxZ; z++) {
                    if (!world.isChunkLoaded(x >> 4, z >> 4)) {
                        continue; // Never force-load neighboring chunks for an explosion scan.
                    }
                    Block block = world.getBlockAt(x, y, z);
                    if (block.getType() != Material.OBSIDIAN || alreadyAffected.contains(block)) {
                        continue;
                    }
                    Location center = block.getLocation().add(0.5D, 0.5D, 0.5D);
                    Vector direction = center.toVector().subtract(origin.toVector());
                    double distance = direction.length();
                    if (distance < 0.01D || distance > radius) {
                        continue;
                    }
                    RayTraceResult trace = world.rayTraceBlocks(origin, direction.normalize(), distance,
                            FluidCollisionMode.NEVER, true);
                    if (trace == null || trace.getHitBlock() == null || !trace.getHitBlock().equals(block)) {
                        continue;
                    }
                    if (registerImpact(block, durability)) {
                        block.setType(Material.AIR, true);
                        float safeYield = Math.max(0.0F, Math.min(1.0F, yield));
                        if (ThreadLocalRandom.current().nextFloat() < safeYield) {
                            world.dropItemNaturally(center, new ItemStack(Material.OBSIDIAN));
                        }
                    }
                    changed = true;
                }
            }
        }
        if (changed) {
            save();
        }
    }

    /** Clears old progress when a block is replaced or removed outside an explosion. */
    public void clear(Block block) {
        String key = key(block);
        if (hits.contains(key)) {
            hits.set(key, null);
            save();
        }
    }

    /** Returns true when this impact reaches durability and the block should be destroyed. */
    private boolean registerImpact(Block block, int durability) {
        String key = key(block);
        String materialName = block.getType().name();
        String savedMaterial = hits.getString(key + ".material", "");
        int previousHits = savedMaterial.equals(materialName) ? Math.max(0, hits.getInt(key + ".hits", 0)) : 0;
        int nextHits = previousHits + 1;
        if (nextHits >= durability) {
            hits.set(key, null);
            return true;
        }
        hits.set(key + ".material", materialName);
        hits.set(key + ".hits", nextHits);
        return false;
    }

    private String key(Block block) {
        return block.getWorld().getUID() + ":" + block.getX() + ":" + block.getY() + ":" + block.getZ();
    }

    private int getDurability(Material material) {
        int value = plugin.getConfig().getInt("block-resistance." + material.name(), 0);
        if (value < 0) {
            plugin.getLogger().warning(String.format(Locale.ROOT,
                    "Negative block-resistance value for %s; treating it as disabled.", material.name()));
            return 0;
        }
        return Math.min(value, 10000);
    }

    private void save() {
        try {
            hits.save(file);
        } catch (IOException exception) {
            plugin.getLogger().severe("Could not save block-hits.yml; hit progress may be lost: " + exception.getMessage());
        }
    }
}
