package com.zsouul.explosioncontrol;

import com.zsouul.explosioncontrol.cache.ExplosionOriginRegistry;
import com.zsouul.explosioncontrol.cache.PendingKnockbackCache;
import com.zsouul.explosioncontrol.command.ExplosionControlCommand;
import com.zsouul.explosioncontrol.config.ConfigManager;
import com.zsouul.explosioncontrol.listener.BedExplosionGuard;
import com.zsouul.explosioncontrol.listener.BlockExplodeListener;
import com.zsouul.explosioncontrol.listener.DragonFireballListener;
import com.zsouul.explosioncontrol.listener.EntityExplodeListener;
import com.zsouul.explosioncontrol.listener.ExplosionDamageListener;
import com.zsouul.explosioncontrol.listener.ExplosionKnockbackListener;
import com.zsouul.explosioncontrol.listener.ExplosionPrimeListener;
import com.zsouul.explosioncontrol.listener.RespawnAnchorExplosionGuard;
import com.zsouul.explosioncontrol.resistance.BlockResistanceManager;
import com.zsouul.explosioncontrol.impulse.TntImpulseManager;
import com.zsouul.explosioncontrol.listener.BlockHitCleanupListener;
import org.bukkit.command.PluginCommand;
import org.bukkit.event.HandlerList;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * Entry point for TNTReinforced, adapted from ExplosionControl.
 * <p>
 * Gives server administrators independent, hot-reloadable control over every explosion source
 * in Minecraft/Purpur 26.2 — {@code enabled}, {@code damage-multiplier}, {@code radius-multiplier},
 * {@code knockback-multiplier}, and {@code block-damage} — via {@code config.yml}.
 * <p>
 * See the {@code listener} package for how each explosion source is hooked, and
 * {@link com.zsouul.explosioncontrol.resolver.ExplosionSourceResolver} for the single place
 * that maps a Bukkit entity/block to a configurable category.
 *
 * @author zSouul
 */
public final class ExplosionControl extends JavaPlugin {

    private ConfigManager configManager;
    private TntImpulseManager tntImpulseManager;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        this.configManager = new ConfigManager(this);
        configManager.load();

        PendingKnockbackCache knockbackCache = new PendingKnockbackCache();
        ExplosionOriginRegistry originRegistry = new ExplosionOriginRegistry();

        BlockResistanceManager blockResistanceManager = new BlockResistanceManager(this);
        this.tntImpulseManager = new TntImpulseManager(this);
        tntImpulseManager.registerRecipe();
        registerListeners(knockbackCache, originRegistry, blockResistanceManager, tntImpulseManager);
        getServer().getPluginManager().registerEvents(new BlockHitCleanupListener(blockResistanceManager), this);
        getServer().getPluginManager().registerEvents(tntImpulseManager, this);
        registerCommand(tntImpulseManager);

        getLogger().info(() -> "TNTReinforced enabled: "
                + configManager.getAllSettings().size() + " explosion categories loaded.");
    }

    @Override
    public void onDisable() {
        if (tntImpulseManager != null) {
            tntImpulseManager.unregisterRecipes();
        }
        HandlerList.unregisterAll(this);
        getLogger().info("TNTReinforced disabled.");
    }

    /**
     * @return the live configuration manager, exposed for tests/tools; listeners receive it
     * directly via constructor injection instead of reaching through the plugin singleton.
     */
    public ConfigManager getConfigManager() {
        return configManager;
    }

    private void registerListeners(PendingKnockbackCache knockbackCache, ExplosionOriginRegistry originRegistry, BlockResistanceManager blockResistanceManager, TntImpulseManager tntImpulseManager) {
        PluginManager pluginManager = getServer().getPluginManager();

        // Entity-sourced explosions: TNT, TNT Minecart, Creeper, Charged Creeper, Wither spawn,
        // Wither Skull, Ghast Fireball, Fireball, Blaze Fireball, End Crystal, Wind Charge.
        pluginManager.registerEvents(new ExplosionPrimeListener(configManager, originRegistry, getLogger()), this);
        pluginManager.registerEvents(new EntityExplodeListener(configManager, originRegistry, blockResistanceManager, tntImpulseManager), this);

        // Block-sourced explosions: Bed, Respawn Anchor.
        pluginManager.registerEvents(new BlockExplodeListener(configManager, blockResistanceManager), this);
        pluginManager.registerEvents(new BedExplosionGuard(configManager), this);
        pluginManager.registerEvents(new RespawnAnchorExplosionGuard(configManager), this);

        // Shared damage-multiplier / knockback-multiplier enforcement for every source above.
        pluginManager.registerEvents(new ExplosionDamageListener(configManager, knockbackCache, originRegistry, getLogger()), this);
        pluginManager.registerEvents(new ExplosionKnockbackListener(knockbackCache), this);

        // Dragon Fireball: Paper API special case, handled entirely separately (see class docs).
        pluginManager.registerEvents(new DragonFireballListener(configManager), this);
    }

    private void registerCommand(TntImpulseManager tntImpulseManager) {
        ExplosionControlCommand handler = new ExplosionControlCommand(this, configManager, tntImpulseManager);
        boolean registered = false;
        for (String name : new String[]{"tntreinforced", "explosioncontrol"}) {
            PluginCommand command = getCommand(name);
            if (command == null) {
                getLogger().warning("Command '" + name + "' is missing from plugin.yml.");
                continue;
            }
            command.setExecutor(handler);
            command.setTabCompleter(handler);
            registered = true;
        }
        if (!registered) {
            getLogger().severe("No TNTReinforced admin command could be registered.");
        }
    }
}
