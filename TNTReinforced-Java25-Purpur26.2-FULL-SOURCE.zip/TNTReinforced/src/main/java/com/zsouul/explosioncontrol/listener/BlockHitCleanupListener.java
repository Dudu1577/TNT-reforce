package com.zsouul.explosioncontrol.listener;

import com.zsouul.explosioncontrol.resistance.BlockResistanceManager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockBurnEvent;
import org.bukkit.event.block.BlockPlaceEvent;

/** Prevents hit counts from leaking to a different block placed at the same coordinates. */
public final class BlockHitCleanupListener implements Listener {
    private final BlockResistanceManager resistanceManager;

    public BlockHitCleanupListener(BlockResistanceManager resistanceManager) {
        this.resistanceManager = resistanceManager;
    }

    @EventHandler(ignoreCancelled = true)
    public void onBreak(BlockBreakEvent event) {
        resistanceManager.clear(event.getBlock());
    }

    @EventHandler(ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent event) {
        resistanceManager.clear(event.getBlockPlaced());
    }

    @EventHandler(ignoreCancelled = true)
    public void onBurn(BlockBurnEvent event) {
        resistanceManager.clear(event.getBlock());
    }
}
