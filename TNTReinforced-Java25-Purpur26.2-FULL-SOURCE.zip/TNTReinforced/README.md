# TNTReinforced — Java 25 / Purpur 26.2

Projeto baseado no código-fonte público do [ExplosionControl](https://github.com/soul-lyte/ExplosionControl), adaptado para reforço cumulativo de blocos e TNT de Impulso.

## O que está incluído

- Configuração de explosões por categoria, herdada do ExplosionControl.
- Resistência cumulativa por material em `config.yml`; o progresso fica em `plugins/TNTReinforced/block-hits.yml`.
- Valores medievais predefinidos: pedra, pedregulho e pedra lisa em 10 impactos; tijolos de pedra e variantes entre 9 e 12; madeira estrutural geralmente 5–6.
- Limpeza do progresso quando blocos são colocados, quebrados ou queimados, evitando que um bloco novo herde contagens antigas.
- Tratamento aproximado especial para obsidiana, que normalmente não aparece na lista de blocos destruíveis da TNT vanilla. O raio é configurável em `block-resistance-special-radius` (padrão 4, máximo 8 para limitar custo).
- Receita alternativa de TNT comum: 2 areias + 2 pólvoras em diagonal → 1 TNT. A receita vanilla continua disponível.
- Receita de TNT de Impulso: 4 TNTs comuns em quadrado 2×2 → 2 TNTs de Impulso.
- A TNT de Impulso é um item identificado por dados persistentes, ativa ao ser usada num bloco, não destrói blocos e lança TNTs já ativadas próximas.
- Comandos `/tntreinforced reload` e `/tntreinforced giveimpulse [jogador]`. O alias `/explosioncontrol reload` continua disponível.
- Permissão administrativa `tntreinforced.admin`, padrão `op`.
- Workflow GitHub Actions em `.github/workflows/build.yml` para compilar com Java 25 e a API Purpur 26.2.

## Estado de validação

**Este pacote-fonte ainda não foi compilado nem executado num servidor real.** O ambiente em que foi preparado tem Java 21, não tem Gradle instalado e não consegue acessar repositórios Maven pela rede. Não use um JAR antigo esperando receber estas funções.

O workflow GitHub Actions compila o código desta pasta, em vez de baixar o projeto upstream e descartar as alterações. Depois de enviar o ZIP para um repositório seu no GitHub:

1. Abra a aba **Actions**.
2. Execute **Build TNTReinforced (Java 25 / Purpur 26.2)**, se não tiver iniciado automaticamente.
3. Aguarde a compilação. Se falhar, envie o primeiro erro completo do log para correção.
4. Se passar, baixe o artefato `TNTReinforced-Java25-Purpur26.2` da execução.
5. Teste numa cópia do servidor com backup antes de substituir qualquer plugin em produção.

## Limitações que exigem teste real

- A resistência especial da obsidiana é uma aproximação por raio e linha de visão, não uma simulação completa da física interna da explosão. O raio fixo não reproduz perfeitamente todos os tipos de explosão.
- A TNT de Impulso lança TNTs primadas num raio de 6 blocos; a velocidade e o comportamento final dependem da física da versão do servidor e de outros plugins.
- Plugins externos que alteram blocos sem disparar eventos Bukkit comuns (por exemplo, certas operações de edição de mundo) podem não limpar a contagem antiga de coordenadas idênticas.
- Uma compilação verde comprova a compilação, não substitui os testes de comportamento no Purpur 26.2.

## Compilação manual

Requer JDK 25 e Gradle 9.1 ou compatível. Na pasta do projeto, execute `gradle clean test build`. O JAR será gerado em `build/libs/`.
